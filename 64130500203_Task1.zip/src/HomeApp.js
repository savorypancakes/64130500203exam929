import logo from './logo.svg';
import './App.css';
import HomeMain from "./components/MainComponent"


export default function HomeApp() {
  return (
    <div className="HomeApp">
      <HomeMain />
    </div>
  );
}

