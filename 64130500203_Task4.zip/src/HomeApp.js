import logo from './logo.svg';
import HomeComp from "./components/HomeComponent"
import './App.css';

export default function HomeApp() {
  return (
    <div className="HomeApp">
      <HomeComp />
    </div>
  );
}

